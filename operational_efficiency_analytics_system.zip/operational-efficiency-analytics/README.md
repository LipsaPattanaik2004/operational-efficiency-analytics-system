# Operational Efficiency Analytics System using SQL, Power BI, Azure & Snowflake

**Project summary (resume-ready):**
Built an end-to-end analytics solution to clean and model production data, create KPI dashboards in Power BI, and automate daily reporting using Azure pipelines and Power Automate.

---

## Repository structure
- `data/` — simulated data CSV/JSON and a generator script
- `sql/` — DDL and transformation SQL scripts (Snowflake/Azure SQL compatible)
- `powerbi/` — DAX measures, report layout and steps to build Power BI report
- `azure/` — instructions & example ADF pipeline JSON snippet
- `powerplatform/` — Power Automate flow description and sample steps
- `docs/` — architecture, assumptions, and interview notes
- `LICENSE`
- `README.md` (this file)

---

## Quick start (create dataset + run)
1. Install Python 3.8+.
2. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate      # Linux / macOS
   venv\Scripts\activate       # Windows
   pip install -r requirements.txt
   ```
3. Generate simulated data:
   ```bash
   python data/generate_data.py --rows 1000
   ```
   This will create sample CSVs in `data/`:
   - `machine_logs.csv`
   - `production_records.csv`
   - `energy_readings.json`

4. Load data into Snowflake/Azure SQL using provided `sql/create_tables.sql` and `sql/load_sample_data_instructions.md`.

5. Run transformations: `sql/transformations.sql` contains SELECT queries to build KPI views.

6. Open Power BI Desktop:
   - Connect to Snowflake/Azure SQL (or load the CSVs directly for demo)
   - Follow `powerbi/ReportLayout.md` and implement DAX from `powerbi/DAX_measures.txt`
   - Publish to Power BI service and set up scheduled refresh (or connect to Azure Data Factory)

7. Automate: Use `powerplatform/PowerAutomate_Flow_Description.md` as a template to create a flow that sends daily KPI emails.

---

## Notes
- This is a **student project**, designed to be buildable by a fresher while showcasing full end-to-end skills required by ABB.
- Replace simulated data with real datasets when available.
