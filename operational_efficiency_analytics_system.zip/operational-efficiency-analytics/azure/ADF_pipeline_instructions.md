# azure/ADF_pipeline_instructions.md

Example approach using Azure Data Factory (ADF):

1. Create Linked Services:
   - Azure Blob Storage (for raw CSVs)
   - Snowflake or Azure SQL (destination)

2. Create Pipelines:
   - Pipeline 'IngestRawData'
     * Copy Activity: Blob Storage -> Staging table
   - Pipeline 'TransformData'
     * Execute Stored Procedure / Script to run transformations.sql
   - Schedule via Trigger: Daily @ 02:00

3. Example: Use 'Copy Activity' with schema mapping for each file.
4. Use Managed Identity or Service Principal for secure auth.
5. For Power BI dataset refresh, use REST API or configure Power BI Gateway + Scheduled Refresh.
