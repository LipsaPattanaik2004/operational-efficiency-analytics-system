# powerbi/ReportLayout.md
Power BI Report Layout (3 pages)

1) Production Efficiency (Landing)
  - Cards: Total Units, Total Defects, Defect Rate %, Avg Units/Min
  - Line chart: Units trend (by day)
  - Bar chart: Units by shift
  - Table: Top machines by units

2) Downtime Analysis
  - Stacked bar: Downtime by reason & machine
  - Heatmap: Downtime hours by day & shift
  - Table: Downtime events with drill-through to machine detail

3) Energy Analytics
  - Line: kWh trend by day
  - KPI: Avg kWh per unit
  - Scatter: Energy vs Units to spot inefficiencies

Tips:
- Use Power Query to merge/join data if not using Snowflake views.
- Use drill-through & bookmarks to create interactive exploration.
- Configure incremental refresh if dataset becomes large.
