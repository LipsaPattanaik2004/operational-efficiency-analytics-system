# docs/architecture.md

## Architecture Overview

[Raw files]
    -> Azure Blob Storage
        -> Azure Data Factory (Copy) -> Snowflake (raw tables)
            -> SQL transformations -> Analytical views
                -> Power BI (reports & dashboards)
                -> Power Automate (daily email & alerts)

## Components
- **Azure Blob Storage:** stores incoming CSVs/JSON (simulated in /data)
- **Azure Data Factory:** orchestrates ingestion & runs transformation jobs
- **Snowflake:** central data warehouse (or Azure SQL for demo)
- **Power BI:** connects to analytical views and serves dashboards
- **Power Automate:** sends scheduled reports/alerts

## Assumptions
- Timezone: UTC for timestamps; adjust as needed
- Data is simulated; production data may require additional cleaning
- Security: use service principals & managed identities in production
