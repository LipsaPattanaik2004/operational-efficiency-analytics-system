# docs/interview_notes.md

Use these bullets to explain the project in interviews:

- Project goal: improve visibility into production efficiency and reduce downtime through data-driven insights.
- End-to-end: from ingestion (ADF) -> storage (Snowflake) -> transformation (SQL views) -> visualization (Power BI) -> automation (Power Automate).
- Key metrics: Total Units, Defect Rate, Downtime minutes, Units per minute (OEE-like), Energy per unit.
- Tools used: SQL, Power BI (Power Query + DAX), Azure Data Factory, Snowflake, Power Automate.
- Challenges solved: merged varied timestamp formats, handled missing values, aggregated shift-level KPIs, automated daily report distribution.
- Next steps: introduce anomaly detection, predictive maintenance, and integrate real-time streaming.
