# powerplatform/PowerAutomate_Flow_Description.md

Goal: Send daily KPI digest email at 08:00 with key metrics and link to Power BI report.

Steps:
1. Trigger: Recurrence (daily at 08:00)
2. Action: Get rows (from SQL or SharePoint) - query vw_daily_production or a summary view
3. Action: Compose HTML body with key metrics (Total Units, Defect Rate, Top 3 Machines)
4. Action: Send an email (Office 365) with subject "Daily Operational KPIs - {{date}}"
5. (Optional) Condition: If defect rate > threshold -> send extra alert to maintenance group
6. (Optional) Create Teams message using Teams connector

Deployment notes:
- Use service account with permissions
- Store SQL connection string in a secure connection
