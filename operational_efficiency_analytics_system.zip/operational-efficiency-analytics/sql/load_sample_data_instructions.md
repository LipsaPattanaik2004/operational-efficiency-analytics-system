-- load_sample_data_instructions.md
1. Use Snowflake UI / SnowSQL or Azure Data Factory to load CSVs/json into the tables created by create_tables.sql
2. For Snowflake:
   - Create a stage, put CSVs in an internal stage or load via Snowpipe for automation
   - Use COPY INTO <table> FROM @stage/file.csv with proper FILE_FORMAT
3. For Azure SQL:
   - Use bcp, BULK INSERT or Azure Data Factory Copy Activity to ingest CSVs into tables
4. After loading raw tables, run transformations.sql to create views used by Power BI.
