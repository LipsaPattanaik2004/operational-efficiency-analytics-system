-- transformations.sql
-- Example queries to derive KPI views

-- 1. Daily production summary
CREATE OR REPLACE VIEW vw_daily_production AS
SELECT
  CAST(p.timestamp AS DATE) AS day,
  p.shift,
  p.machine_id,
  SUM(p.units_produced) AS total_units,
  SUM(p.defects) AS total_defects,
  CASE WHEN SUM(p.units_produced) = 0 THEN 0 ELSE ROUND(100.0 * SUM(p.units_produced - p.defects) / SUM(p.units_produced),2) END AS quality_pct
FROM production_records p
GROUP BY CAST(p.timestamp AS DATE), p.shift, p.machine_id;

-- 2. Downtime aggregated
CREATE OR REPLACE VIEW vw_downtime AS
SELECT
  CAST(m.timestamp AS DATE) AS day,
  m.machine_id,
  SUM(m.downtime_minutes) AS downtime_minutes,
  COUNT(*) FILTER (WHERE m.downtime_minutes > 0) AS downtime_events
FROM machine_logs m
GROUP BY CAST(m.timestamp AS DATE), m.machine_id;

-- 3. Energy daily
CREATE OR REPLACE VIEW vw_energy AS
SELECT
  CAST(e.timestamp AS DATE) AS day,
  e.meter_id,
  SUM(e.kwh) AS total_kwh
FROM energy_readings e
GROUP BY CAST(e.timestamp AS DATE), e.meter_id;

-- 4. OEE-like metric (illustrative)
CREATE OR REPLACE VIEW vw_oee AS
SELECT
  p.day,
  p.machine_id,
  p.total_units,
  COALESCE(d.downtime_minutes,0) AS downtime_minutes,
  ROUND( (p.total_units::float / NULLIF( (24*60 - COALESCE(d.downtime_minutes,0)),0) )::numeric,2) AS units_per_minute
FROM vw_daily_production p
LEFT JOIN vw_downtime d ON p.day = d.day AND p.machine_id = d.machine_id;
